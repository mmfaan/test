# Lumin Infinity Group — Official Website

> مجموعة شركات لومين انفينيتي | الأمن السيبراني · الذكاء الاصطناعي · الأبحاث

---

## هيكل الملفات

```
lumin-infinity/
├── index.html              ← الصفحة الرئيسية
├── server.js               ← خادم Express (Node.js)
├── package.json
├── .env.example            ← نموذج متغيرات البيئة
├── .gitignore
│
├── css/
│   ├── variables.css       ← متغيرات التصميم (ألوان، خطوط، مسافات)
│   ├── base.css            ← إعادة الضبط والطباعة
│   ├── layout.css          ← الحاوية، الهيدر، الفوتر، الشبكات
│   ├── components.css      ← الأزرار، البطاقات، المودال، الواجهات
│   ├── animations.css      ← جميع الـ keyframes وانيماشنات الـ reveal
│   ├── sections.css        ← أنماط خاصة بكل قسم (hero, about, sectors...)
│   └── responsive.css      ← جميع الـ media queries
│
└── js/
    ├── main.js             ← نقطة الدخول الرئيسية (ES Module)
    ├── config.js           ← إعدادات مركزية
    ├── i18n.js             ← نظام الترجمة عربي/إنجليزي
    ├── audio.js            ← مؤثرات صوتية (Web Audio API)
    ├── cursor.js           ← مؤشر مخصص + ذيل الجسيمات
    ├── preloader.js        ← شاشة التحميل
    ├── forms.js            ← نماذج التواصل والنشرة البريدية
    │
    ├── canvas/
    │   ├── network.js      ← شبكة الجسيمات التفاعلية (Hero)
    │   ├── signal.js       ← خريطة إشارات الشبكة المتحركة
    │   ├── matrix.js       ← وضع المصفوفة (Easter egg)
    │   └── radar.js        ← مخطط الرادار SVG
    │
    ├── ui/
    │   ├── header.js       ← الهيدر، التمرير، العودة للأعلى
    │   ├── theme.js        ← تبديل المظهر الفاتح/الداكن
    │   ├── cmdpalette.js   ← لوحة الأوامر (Ctrl+K)
    │   ├── reveal.js       ← انيماشن الظهور، العداد، الكاروسيل، الإمالة، المغناطيس
    │   └── faq.js          ← أكورديون الأسئلة الشائعة
    │
    ├── live/
    │   ├── geo.js          ← بيانات IP الجغرافية عبر /api/geo
    │   ├── crypto.js       ← أسعار العملات عبر /api/crypto
    │   └── terminal.js     ← محاكاة طرفية SOC
    │
    └── lab/
        ├── cipher.js       ← شيفرة قيصر
        ├── password.js     ← محلل قوة كلمة المرور
        └── morse.js        ← مترجم شيفرة مورس
```

---

## تشغيل المشروع

### 1. المتطلبات
- **Node.js** 18 أو أحدث
- **npm** 9+

### 2. التثبيت

```bash
# استنسخ أو انسخ مجلد المشروع
cd lumin-infinity

# ثبّت الاعتماديات
npm install

# انسخ ملف متغيرات البيئة
cp .env.example .env
# ثم افتح .env وعدّل القيم حسب بيئتك
```

### 3. التشغيل (وضع التطوير)

```bash
npm run dev
# أو
npx nodemon server.js
```

ثم افتح المتصفح على: **http://localhost:3000**

### 4. الإنتاج

```bash
NODE_ENV=production npm start
```

---

## متغيرات البيئة المهمة

| المتغير | الوصف |
|---|---|
| `PORT` | منفذ الخادم (افتراضي: 3000) |
| `NODE_ENV` | `development` أو `production` |
| `CORS_ORIGINS` | النطاقات المسموح بها (فاصلة بينها) |
| `CACHE_TTL_IP` | مدة كاش بيانات IP بالثواني |
| `CACHE_TTL_CRYPTO` | مدة كاش أسعار العملات بالثواني |

---

## واجهات API

| المسار | الطريقة | الوصف |
|---|---|---|
| `/api/geo` | GET | بيانات IP/جغرافية للزائر (عبر ipapi.co) |
| `/api/crypto` | GET | أسعار BTC/ETH/SOL (عبر CoinGecko) |
| `/api/contact` | POST | إرسال رسالة تواصل |

---

## النشر على Netlify / Vercel

الموقع **يحتاج خادم Node.js** لتشغيل الـ API routes.

- **Netlify**: استخدم Netlify Functions أو حوّل routes الـ API إلى functions منفصلة.
- **Vercel**: استخدم `vercel.json` مع rewrites لتوجيه `/api/*` لـ serverless functions.
- **VPS / DigitalOcean**: شغّل `server.js` مباشرة خلف Nginx.

---

## رئيس المجموعة

**محمد محسن فالح** — مواليد البصرة 2008  
الموقع الشخصي: [muhamed1.netlify.app](https://muhamed1.netlify.app)  
البريد: mmhsm16@gmail.com

---

## الترخيص

UNLICENSED — جميع الحقوق محفوظة لمجموعة لومين انفينيتي © 2026
